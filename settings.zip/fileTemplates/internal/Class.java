#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/** 
    \* Created with IntelliJ IDEA. 
    \* User: ${USER} 
    \* Date: ${DATE} 
    \* Time: ${TIME} 
    \* To change this template use File | Settings | File Templates. 
    \* Description: 
\*/ 
public class ${NAME} {
}
